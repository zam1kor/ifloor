# ifloor starter kit

## Usage
```bash
$ pip install -e . # install package and dependencies
#[...installation...]
$ ifloor # run the application
```
## Requirements:
 - Python (everything > 3.8 should work actually)
 - Have to be in BoschARENA network
